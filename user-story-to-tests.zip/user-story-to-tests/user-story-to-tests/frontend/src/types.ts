export interface GenerateRequest {
  storyTitle: string
  acceptanceCriteria: string
  description?: string
  additionalInfo?: string
  categories?: string[]
  jiraId?: string
}

export interface TestCase {
  id: string
  title: string
  steps: string[]
  testData?: string
  expectedResult: string
  category: string
}

export interface GenerateResponse {
  cases: TestCase[]
  model?: string
  promptTokens: number
  completionTokens: number
  chosenCategories?: string[]
  chosenJiraId?: string
  jiraSummary?: string
  jiraDescription?: string
}

export interface TestDataRequest {
  jiraId?: string
  sampleCount?: number
}

export type TestDataRecord = Record<string, string | number | boolean | null>

export interface TestDataResponse {
  records: TestDataRecord[]
  pattern?: Array<{ name: string; type: string; details?: any }>
}