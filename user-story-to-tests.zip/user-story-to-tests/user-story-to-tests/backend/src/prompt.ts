import { GenerateRequest, allowedCategories } from './schemas'

export const SYSTEM_PROMPT = `You are a senior QA engineer with expertise in creating comprehensive test cases from user stories. Your task is to analyze user stories and generate detailed test cases.

CRITICAL: You must return ONLY valid JSON matching this exact schema:

{
  "cases": [
    {
      "id": "TC-001",
      "title": "string",
      "steps": ["string", "..."],
      "testData": "string (optional)",
      "expectedResult": "string",
      "category": "string (e.g., Positive|Negative|Edge|Authorization|Non-Functional)"
    }
  ],
  "model": "string (optional)",
  "promptTokens": 0,
  "completionTokens": 0
}

Guidelines:
- Generate test case IDs like TC-001, TC-002, etc.
- Write concise, imperative steps (e.g., "Click login button", "Enter valid email")
- Include Positive, Negative, and Edge test cases where relevant
- Categories: Positive, Negative, Edge, Authorization, Non-Functional
- Steps should be actionable and specific
- Expected results should be clear and measurable

Return ONLY the JSON object, no additional text or formatting.`

export function buildPrompt(request: GenerateRequest & { jiraSummary?: string; jiraDescription?: string; jiraId?: string }): string {
  const { storyTitle, acceptanceCriteria, description, additionalInfo, jiraSummary, jiraDescription, jiraId } = request
  const categories = (request as any).categories as string[] | undefined
  const categoriesInstruction = Array.isArray(categories) && categories.length > 0
    ? `Only generate test cases for the following categories: ${categories.join(', ')}.`
    : `Generate test cases for all categories: ${allowedCategories.join(', ')}.`
  
  let userPrompt = `Generate comprehensive test cases for the following user story:

Story Title: ${storyTitle}

Acceptance Criteria:
${acceptanceCriteria}
`

  if (description) {
    userPrompt += `\nDescription:
${description}
`
  }

  if (additionalInfo) {
    userPrompt += `\nAdditional Information:
${additionalInfo}
`
  }

  if (jiraId || jiraSummary || jiraDescription) {
    userPrompt += `\nJIRA Issue: ${jiraId ?? 'N/A'}\n`
    if (jiraSummary) userPrompt += `JIRA Summary: ${jiraSummary}\n`
    if (jiraDescription) userPrompt += `JIRA Description:\n${jiraDescription}\n`
  }

  userPrompt += `\n${categoriesInstruction} Generate test cases covering positive scenarios, negative scenarios, edge cases, and any authorization or non-functional requirements as applicable. Return only the JSON response.`

  return userPrompt
}

export function buildTestDataPrompt(context: { jiraId?: string; jiraSummary?: string; jiraDescription?: string; sampleCount?: number }): string {
  const { jiraId, jiraSummary, jiraDescription, sampleCount = 5 } = context
  let prompt = `You are a data generator. Based on the JIRA story information below, infer relevant test data fields and produce a JSON object with two keys: "pattern" and "records". \n
Return ONLY valid JSON.\n
pattern: an array of field definitions (name, type, optional details).\n
records: an array of ${sampleCount} sample records matching the pattern.\n
Use field types similar to Mockaroo (e.g., Full Name, Email, Integer, Float, Date, Boolean, Phone).\n
Example output format: { "pattern": [{"name":"id","type":"Number"}], "records": [{"id":1}]}\n
JIRA Context:\n`

  if (jiraId) prompt += `JIRA: ${jiraId}\n`
  if (jiraSummary) prompt += `Summary: ${jiraSummary}\n`
  if (jiraDescription) prompt += `Description: ${jiraDescription}\n`

  prompt += `\nAnalyze the story and generate fields relevant to the features & acceptance criteria. Produce realistic sample values. Return only the JSON object with pattern and records.`
  return prompt
}