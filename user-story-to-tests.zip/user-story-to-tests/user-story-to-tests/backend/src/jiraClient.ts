import fetch from 'node-fetch'

export async function fetchJiraIssue(issueId: string): Promise<{ summary?: string; description?: string }> {
  const base = process.env.JIRA_BASE_URL
  const user = process.env.JIRA_USER
  const apiKey = process.env.JIRA_API_KEY

  if (!base) throw new Error('JIRA_BASE_URL not configured on the server')

  const url = `${base.replace(/\/$/, '')}/rest/api/2/issue/${encodeURIComponent(issueId)}?fields=summary,description`
  const headers: Record<string,string> = { Accept: 'application/json' }

  if (user && apiKey) {
    const auth = Buffer.from(`${user}:${apiKey}`).toString('base64')
    headers.Authorization = `Basic ${auth}`
  }

  const res = await fetch(url, { headers })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`JIRA fetch failed: ${res.status} ${res.statusText} ${txt}`)
  }

  const data: any = await res.json()
  const fields: any = data && data.fields ? data.fields : {}
  return {
    summary: fields.summary,
    description: typeof fields.description === 'string' ? fields.description : ''
  }
}
